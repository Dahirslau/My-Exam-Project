-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 16, 2015 at 10:56 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `education_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `suggestions`
--

CREATE TABLE IF NOT EXISTS `suggestions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(22) NOT NULL,
  `gender` varchar(24) NOT NULL,
  `nationality` varchar(25) NOT NULL,
  `tel` varchar(26) NOT NULL,
  `email` varchar(27) NOT NULL,
  `comment` varchar(26) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `suggestions`
--

INSERT INTO `suggestions` (`id`, `name`, `gender`, `nationality`, `tel`, `email`, `comment`) VALUES
(1, 'dahir', 'Male', 'uganda', '+256791346033', 'dalasaa@hotmail.com', '        hi guys   ');

-- --------------------------------------------------------

--
-- Table structure for table `tbcredit_card`
--

CREATE TABLE IF NOT EXISTS `tbcredit_card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(22) NOT NULL,
  `age` varchar(24) NOT NULL,
  `gender` varchar(25) NOT NULL,
  `nationality` varchar(26) NOT NULL,
  `tel` varchar(27) NOT NULL,
  `email` varchar(26) NOT NULL,
  `f` varchar(28) NOT NULL,
  `fee` varchar(29) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbcredit_card`
--

INSERT INTO `tbcredit_card` (`id`, `name`, `age`, `gender`, `nationality`, `tel`, `email`, `f`, `fee`) VALUES
(1, 'dahir', '22', 'Male', 'uganda', '+23545444566', 'dalasaa@hotmail.com', '', '1000000ug'),
(5, 'awale', '33', 'Male', 'uganda', '+256791346033', 'awale@hotmail.com', '', '1000000ug'),
(7, 'ali', '33', 'Male', 'uganda', '+256791346033', 'ali@hotmail.com', 'bait', '1000000ug'),
(8, 'halima', '33', 'Female', 'uganda', '+256791346090', 'halima@hotmail.com', 'bait', '1000000ug');

-- --------------------------------------------------------

--
-- Table structure for table `tbmembers`
--

CREATE TABLE IF NOT EXISTS `tbmembers` (
  `member_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(23) NOT NULL,
  `last_name` varchar(24) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` varchar(33) NOT NULL,
  PRIMARY KEY (`member_id`),
  UNIQUE KEY ` email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `tbmembers`
--

INSERT INTO `tbmembers` (`member_id`, `first_name`, `last_name`, `email`, `password`) VALUES
(1, 'dahir', 'mohamed', 'dalasaa@gmail.com', ''),
(2, 'dahir', 'mohamed', 'dama1@gmail.com', 'a9b7ba70783b617e9998dc4dd82eb3c5'),
(4, 'dahir', 'mohamed', 'dalasaa@hotmail.com', 'a9b7ba70783b617e9998dc4dd82eb3c5'),
(7, 'dahir', 'mohamed', 'dalasaa2@hotmail.com', '202cb962ac59075b964b07152d234b70'),
(8, 'jafar', 'kukay', 'damaa@gmail.com', '202cb962ac59075b964b07152d234b70'),
(9, 'sai', 'mohamed', 'yama@hotmail.com', '202cb962ac59075b964b07152d234b70'),
(10, 'gedi', 'ali', 'gedi@hotmail.com', '202cb962ac59075b964b07152d234b70'),
(12, 'faid', 'ali', 'faid@hotmail.com', '202cb962ac59075b964b07152d234b70'),
(15, 'dahir', 'mohamed', 'mohamed@hotmail.com', '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- Table structure for table ` tbpositions`
--

CREATE TABLE IF NOT EXISTS ` tbpositions` (
  `position_id` int(11) NOT NULL AUTO_INCREMENT,
  `position_name` varchar(23) NOT NULL,
  PRIMARY KEY (`position_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table ` tbpositions`
--

INSERT INTO ` tbpositions` (`position_id`, `position_name`) VALUES
(1, 'BSCE'),
(2, 'BSC.IS'),
(3, 'BAIT'),
(4, 'BACS');
